from orders_data_handler import load_orders
from orders_data_processor import process_orders
from orders_bar_chart_web_page import plot_order_bar_chart

def main():
    file_path = "orders.csv"  # Make sure this file exists
    orders = load_orders(file_path)
    
    if not orders.empty:
        processed = process_orders(orders)
        plot_order_bar_chart(processed)

if __name__ == "__main__":
    main()
